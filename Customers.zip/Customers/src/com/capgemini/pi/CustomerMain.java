package com.capgemini.pi;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bean.Customerbean;
import com.capgemini.exception.CustomersException;
import com.capgemini.service.CustomerServiceImpl;
import com.capgemini.service.ICustomerService;
//import com.capgemini.dao;
import java.lang.NullPointerException;

@SuppressWarnings("unused")
public class CustomerMain  {

	static Scanner sc = new Scanner(System.in);
	static ICustomerService customerService = null;
	static CustomerServiceImpl customerServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws Exception {
		PropertyConfigurator.configure("resources//log4j.properties");
		Customerbean customerbean = null;

		String customer_id = null;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   Customer Application ");
			System.out.println("_______________________________\n");

			System.out.println("1.Add Customer ");
			System.out.println("2.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (customerbean  == null) {
						customerbean  = populateCustomerbean();
						 System.out.println(customerbean);
					}

					try {
						customerService = new CustomerServiceImpl();
						customer_id = customerService.addCustomerDetails(customerbean);

						System.out.println("cust details  has been successfully registered ");
						System.out.println("cust  ID Is: " + customer_id);

					} catch (CustomersException customersException) {
						logger.error("exception occured", customersException);
						System.out.println("ERROR : "
								+ customersException.getMessage());
					} finally {
						customer_id = null;
						customerService = null;
						customerbean = null;
					}

					break;


				case 2:

					System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
		}

		}// end of while
	}

	private static Customerbean populateCustomerbean() throws Exception {

		// Reading and setting the values for the donorBean
		
		Customerbean customerbean = new Customerbean();

		System.out.println("\n Customer Details");

		System.out.println("Enter  name: ");
		customerbean.setName(sc.next());
		System.out.println("Enter age: ");
		customerbean.setAge(sc.next());
		System.out.println("Enter phone: ");
		customerbean.setPhoneNumber(sc.next());
		System.out.println("Enter product int: ");
		customerbean.setProductInterested(sc.next());
		
	
		
        customerServiceImpl = new CustomerServiceImpl();
//System.out.println("After creating customer service impl object");

		try {
			customerServiceImpl.validateCustomer(customerbean);
			
			System.out.println("after validate customer");
			return customerbean;
		} catch (CustomersException customersException) {
			logger.error("exception occured", customersException);
			System.err.println("Invalid data:");
			System.err.println(customersException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}
